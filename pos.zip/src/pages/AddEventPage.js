import React from 'react'
import NewEvent from '../components/NewEvent'

export default function AddEventPage() {
  return (
    <div>
      <NewEvent />
    </div>
  )
}
