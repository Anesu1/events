import React, { useEffect, useState } from 'react';
import {useSelector, useDispatch} from 'react-redux'
import { getUser } from '../redux/authSlice';
import {getEvents} from "../redux/eventSlice"
import { Link } from 'react-router-dom';

export default function Dashboard() {
  const { user } = useSelector(state => state.auth)
  const { events } = useSelector(state => state.events)
  const [timer, setTimer] = useState(null);
    const dispatch = useDispatch()
    const newuser =  user && localStorage.getItem("user")
  console.log(events)
  

    useEffect(() => {
      
        const intervalId = setInterval(() => {
          dispatch(getUser());
          dispatch(getEvents());
        }, 60000); // 60000 milliseconds = 1 minute

        setTimer(intervalId);

        return () => {
          // Clear the interval when the component unmounts
          clearInterval(timer);
        };
    }, [dispatch, events, timer])
  
  useEffect(() => {
    dispatch(getUser());
    dispatch(getEvents());
  },[dispatch])
  return (
    <div>
          <h1>Dashboard</h1>
      <p className='capitalize'>Welcome {user?.username}</p>
      {events.length === 0 ? (
        <p>Hapana kana chinhu yet</p>
      ) : (<>{ events.map((item) => {
        return (
          <div key={item.event_id}>
            <h2>{item.title}</h2>
            <div className="buttons">
              <Link
                to="/update-event"
                className="bg-green-500 hover:opacity-80 text-white font-medium rounded-lg text-sm w-full sm:w-auto px-5 py-2.5 text-center"
              >
                Edit
              </Link>
              <button className="bg-red-500 hover:opacity-80 text-white font-medium rounded-lg text-sm w-full sm:w-auto px-5 py-2.5 text-center">
                Delete
              </button>
            </div>
          </div>
        );
      })}
      </>
          
      )}
      
    </div>
  )
}
