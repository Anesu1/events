import React from 'react'
import CalendarComponent from '../components/CalendarComponent'

export default function CalendarPage() {
  return (
    <>
      <CalendarComponent />
    </>
  )
}
